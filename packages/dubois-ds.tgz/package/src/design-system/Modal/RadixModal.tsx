import { css } from '@emotion/react';
import * as Dialog from '@radix-ui/react-dialog';
import type { ModalProps as AntDModalProps } from 'antd';
import classNames from 'classnames';
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';

import type { Theme } from '../../theme';
import type { ButtonProps } from '../Button';
import { Button } from '../Button';
import {
  augmentWithDataComponentProps,
  useDesignSystemEventComponentCallbacks,
  DesignSystemEventProviderAnalyticsEventTypes,
  DesignSystemEventProviderComponentTypes,
} from '../DesignSystemEventProvider/DesignSystemEventProvider';
import {
  DesignSystemEventSuppressInteractionProviderContext,
  DesignSystemEventSuppressInteractionTrueContextValue,
} from '../DesignSystemEventProvider/DesignSystemEventSuppressInteractionProvider';
import { getAnimationCss } from '../DesignSystemProvider';
import { useDesignSystemTheme } from '../Hooks';
import { CloseIcon, DangerIcon } from '../Icon';
import { Typography } from '../Typography';
import type { AnalyticsEventPropsWithStartInteraction, HTMLDataAttributes } from '../types';
import { getDarkModePortalStyles, getShadowScrollStyles } from '../utils';
import { addDebugOutlineStylesIfEnabled } from '../utils/debug';
import { useNotifyOnFirstView } from '../utils/useNotifyOnFirstView';
import { useStableUuidV4 } from '../utils/useStableUuidV4';

// Context for components to detect if they're inside a RadixModal and get the modal root element
// This is useful for components like Select that need to portal to the modal instead of body
interface RadixModalContextValue {
  modalRootElement: HTMLElement | null;
}

const RadixModalContext = React.createContext<RadixModalContextValue | null>(null);

export interface RadixModalContextResult {
  /** True if the component is inside a RadixModal, false otherwise */
  isInsideRadixModal: boolean;
  /** The modal root element, or null if not inside a modal or if the ref is not yet set */
  modalRoot: HTMLElement | null;
}

/**
 * Hook to detect if a component is inside a RadixModal and get the modal root element.
 * Returns an object with `isInsideRadixModal` boolean and `modalRoot` element.
 * This is useful for components like Select that need to portal to the modal instead of body.
 *
 * @example
 * const { isInsideRadixModal, modalRoot } = useRadixModalContext();
 * if (isInsideRadixModal && modalRoot) {
 *   // Use modalRoot as portal target for dropdowns, selects, etc.
 * }
 */
export function useRadixModalContext(): RadixModalContextResult {
  const context = React.useContext(RadixModalContext);
  return {
    isInsideRadixModal: context !== null,
    modalRoot: context?.modalRootElement ?? null,
  };
}

export interface ModalProps
  extends
    HTMLDataAttributes,
    AnalyticsEventPropsWithStartInteraction<DesignSystemEventProviderAnalyticsEventTypes.OnView> {
  dangerouslySetAntdProps?: Partial<
    Pick<
      AntDModalProps,
      | 'bodyStyle'
      | 'width'
      | 'wrapProps'
      | 'closable'
      | 'maskClosable'
      | 'keyboard'
      | 'centered'
      | 'closeIcon'
      | 'style'
      | 'mask'
      | 'modalRender'
      | 'okType'
      | 'maskStyle'
    >
  >;
  visible?: boolean;
  onOk?: (...args: any[]) => any;
  onCancel?: (...args: any[]) => any;
  title?: React.ReactNode;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'normal' | 'wide' | 'extraWide';
  verticalSizing?: 'dynamic' | 'maxed_out';
  confirmLoading?: boolean;
  afterClose?: () => void;
  okText?: React.ReactNode;
  cancelText?: React.ReactNode;
  // No-op, Radix does this by default, but we need to keep this for backwards compatibility
  destroyOnClose?: boolean;
  wrapClassName?: string;
  className?: string;
  getContainer?: () => HTMLElement | null;
  zIndex?: number;
  okButtonProps?: Omit<ButtonProps, 'componentId' | 'analyticsEvents'>;
  cancelButtonProps?: Omit<ButtonProps, 'componentId' | 'analyticsEvents'>;
  modalRender?: (node: React.ReactNode) => React.ReactNode;
  autoFocusButton?: 'ok' | 'cancel';
  truncateTitle?: boolean;
  /**
   * @default true
   * Prevents auto focusing the first focusable element when the modal is opened */
  preventAutoFocus?: boolean;
}

const SIZE_PRESETS = {
  normal: 640,
  wide: 880,
  extraWide: 1200,
};

const modalContainerStyles = (theme: Theme) =>
  css({
    ...addDebugOutlineStylesIfEnabled(theme),
    ...getAnimationCss(theme.options.enableAnimation),
  });

const wrapperStyles = css({
  position: 'absolute',
  inset: 0,
  width: '100%',
  height: '100%',
});

const overlayStyles = (theme: Theme, zIndex: number, maskStyle?: React.CSSProperties) =>
  css({
    position: 'fixed',
    inset: 0,
    backgroundColor: theme.colors.overlayOverlay,
    zIndex,
    borderRadius: theme.borders.borderRadiusSm,
    pointerEvents: 'none',
    width: '100%',
    height: '100%',
    ...maskStyle,
  });

const modalContentStyles = (theme: Theme, maxedOutHeight: boolean) => {
  const MODAL_PADDING = theme.spacing.lg;
  return css({
    backgroundColor: theme.colors.backgroundPrimary,
    maxHeight: '90vh',
    height: maxedOutHeight ? '90vh' : undefined,
    paddingBottom: MODAL_PADDING,
    display: 'flex',
    flexDirection: 'column',
    borderRadius: theme.borders.borderRadiusLg,
    boxShadow: theme.shadows.xl,
    overflow: 'auto',
    ...getDarkModePortalStyles(theme),
    transform: 'unset !important',
    top: 'unset !important',
    left: 'unset !important',
    alignSelf: 'center',
    justifySelf: 'center',
  });
};

const modalHeaderStyles = (theme: Theme) =>
  css({
    display: 'flex',
    background: 'transparent',
    paddingTop: theme.spacing.md,
    paddingLeft: theme.spacing.lg,
    paddingRight: theme.spacing.md,
    paddingBottom: theme.spacing.md,
  });

const modalTitleStyles = (theme: Theme, truncated?: boolean, closable?: boolean) => {
  const MODAL_PADDING = theme.spacing.lg;
  const headerHeight = 64;
  return css({
    fontSize: theme.typography.fontSizeXl,
    lineHeight: theme.typography.lineHeightXl,
    fontWeight: theme.typography.typographyBoldFontWeight,
    paddingRight: closable ? MODAL_PADDING : theme.spacing.sm,
    minHeight: headerHeight / 2,
    display: 'flex',
    overflowWrap: 'anywhere',
    maxWidth: '100%',
    ...(truncated && {
      textOverflow: 'ellipsis',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      width: '100%',
    }),
    // TODO (DUBOIS-320): needed for solution to prevent auto focusing the first focusable element when the modal is opened -- mimic antd behavior
    '&:focus': {
      outline: 'none',
    },
  });
};

const modalBodyStyles = (theme: Theme, hasFooter: boolean, isScrollable: boolean) => {
  const MODAL_PADDING = theme.spacing.lg;
  const headerHeight = 64;
  const footerHeight = hasFooter ? 52 : 0;
  const CONTENT_BUFFER = 8;
  const bodyMaxHeight = `calc(90vh - ${headerHeight}px - ${footerHeight}px - ${MODAL_PADDING}px)`;

  return css({
    overflowY: 'auto',
    maxHeight: bodyMaxHeight,
    paddingLeft: MODAL_PADDING,
    paddingRight: MODAL_PADDING,
    paddingTop: CONTENT_BUFFER,
    paddingBottom: CONTENT_BUFFER,
    ...(isScrollable && getShadowScrollStyles(theme)),
  });
};

const modalFooterStyles = (theme: Theme, prefixCls: string, hasCustomFooter: boolean) => {
  const MODAL_PADDING = theme.spacing.lg;
  const CONTENT_BUFFER = 8;
  const footerHeight = 52;

  return css({
    ...(hasCustomFooter
      ? { display: 'block' } // match antd footer styles
      : {
          display: 'flex',
          justifyContent: 'flex-end',
          boxSizing: 'border-box',
          '& > * + *': {
            marginLeft: theme.spacing.sm,
          },
        }),
    height: footerHeight,
    paddingTop: theme.spacing.lg - CONTENT_BUFFER,
    paddingLeft: MODAL_PADDING,
    paddingRight: MODAL_PADDING,
    marginTop: 'auto',
    [`.${prefixCls}-dropdown-button > .${prefixCls}-btn:nth-of-type(2)`]: {
      marginLeft: -1,
    },
  });
};

function DefaultFooter({
  componentId,
  onOk,
  onCancel,
  confirmLoading,
  okText,
  cancelText,
  okButtonProps,
  cancelButtonProps,
  autoFocusButton,
  shouldStartInteraction,
}: Pick<
  ModalProps,
  | 'componentId'
  | 'onOk'
  | 'onCancel'
  | 'confirmLoading'
  | 'okText'
  | 'cancelText'
  | 'okButtonProps'
  | 'cancelButtonProps'
  | 'autoFocusButton'
  | 'shouldStartInteraction'
>) {
  const handleCancel = (e: React.MouseEvent<HTMLButtonElement>) => onCancel?.(e);
  const handleOk = (e: React.MouseEvent<HTMLButtonElement>) => onOk?.(e);

  return (
    <>
      {cancelText && (
        <Button
          componentId={componentId ? `${componentId}.footer.cancel` : 'modal.close'}
          onClick={handleCancel}
          autoFocus={autoFocusButton === 'cancel'}
          dangerouslyUseFocusPseudoClass
          shouldStartInteraction={shouldStartInteraction}
          {...cancelButtonProps}
        >
          {cancelText}
        </Button>
      )}
      {okText && (
        <Button
          componentId={componentId ? `${componentId}.footer.ok` : 'modal.ok'}
          loading={confirmLoading}
          onClick={handleOk}
          type="primary"
          autoFocus={autoFocusButton === 'ok'}
          dangerouslyUseFocusPseudoClass
          shouldStartInteraction={shouldStartInteraction}
          {...okButtonProps}
        >
          {okText}
        </Button>
      )}
    </>
  );
}

export function Modal(props: ModalProps): JSX.Element {
  return (
    <DesignSystemEventSuppressInteractionProviderContext.Provider
      value={DesignSystemEventSuppressInteractionTrueContextValue}
    >
      <ModalInternal {...props} />
    </DesignSystemEventSuppressInteractionProviderContext.Provider>
  );
}

function ModalInternal({
  componentId,
  analyticsEvents = [DesignSystemEventProviderAnalyticsEventTypes.OnView],
  okButtonProps,
  cancelButtonProps,
  dangerouslySetAntdProps,
  children,
  title,
  footer,
  size = 'normal',
  verticalSizing = 'dynamic',
  autoFocusButton,
  truncateTitle,
  shouldStartInteraction,
  visible = false,
  onOk,
  onCancel,
  afterClose,
  confirmLoading,
  okText,
  cancelText,
  destroyOnClose,
  wrapClassName,
  className,
  getContainer,
  zIndex,
  modalRender,
  preventAutoFocus = true,
  ...restProps
}: ModalProps) {
  const { theme, classNamePrefix } = useDesignSystemTheme();
  const memoizedAnalyticsEvents = useMemo(() => analyticsEvents, [analyticsEvents]);
  const eventContext = useDesignSystemEventComponentCallbacks({
    componentType: DesignSystemEventProviderComponentTypes.Modal,
    componentId,
    analyticsEvents: memoizedAnalyticsEvents,
    shouldStartInteraction,
  });
  const { elementRef } = useNotifyOnFirstView<HTMLElement>({ onView: eventContext.onView });
  const contentRef = useRef<HTMLDivElement>(null);
  const modalRootRef = useRef<HTMLDivElement>(null);
  const triggerElementRef = useRef<HTMLElement | null>(null);
  const emitViewEventThroughVisibleEffect = dangerouslySetAntdProps?.closable === false;
  const isViewedViaVisibleEffectRef = useRef(false);
  const uuid = useStableUuidV4();

  const [open, setOpen] = useState(visible);
  const prevOpenRef = useRef(open);

  useLayoutEffect(() => {
    if (visible) {
      // Store the currently focused element when modal opens
      triggerElementRef.current = document.activeElement as HTMLElement;
    }
    setOpen(Boolean(visible));
  }, [visible]);

  // handle refocus when the component is closed using visible props
  useEffect(() => {
    if (!visible && !open && triggerElementRef.current) {
      // setTimeout is necessary to ensure the focus is applied after the modal is closed
      setTimeout(() => triggerElementRef.current?.focus(), 0);
    }
  }, [visible, open]);

  // handle refocus when the component is unmounted entirely instead of using visible props
  useEffect(() => {
    return () => {
      if (triggerElementRef.current) {
        setTimeout(() => triggerElementRef.current?.focus(), 0);
      }
    };
  }, []);

  useEffect(() => {
    if (emitViewEventThroughVisibleEffect && !isViewedViaVisibleEffectRef.current && visible === true) {
      isViewedViaVisibleEffectRef.current = true;
      eventContext.onView();
    }
  }, [visible, emitViewEventThroughVisibleEffect, eventContext]);

  // Fix Radix UI pointer-events bug where body gets stuck with pointer-events: none
  // When Radix components (DropdownMenu, Dialog, etc.) open, they set pointer-events: none
  // on the body to prevent interactions outside the modal. However, this can sometimes
  // persist after the component closes, making the entire page uninteractive.
  // This affects third-party modals (like Stripe) and general page interactions.
  // For fix, see: https://github.com/radix-ui/primitives/issues/2122#issuecomment-1666753771
  useEffect(() => {
    // Radix fix
    if (open) {
      // Pushing the change to the end of the call stack to ensure pointer events are restored
      // after Radix has finished its setup, preventing the body from staying locked
      const timer = setTimeout(() => {
        document.body.style.pointerEvents = '';
      }, 0);
      return () => clearTimeout(timer);
    } else {
      // Explicitly restore pointer events when dropdown closes
      document.body.style.pointerEvents = 'auto';
      return undefined;
    }
  }, [open]);

  useEffect(() => {
    if (prevOpenRef.current && !open) {
      afterClose?.();
    }
    prevOpenRef.current = open;
  }, [open, afterClose]);

  const [isScrollable, setIsScrollable] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  // Effect to only add shadow scroll styles if the content is scrollable
  useEffect(() => {
    if (!open) return;

    const resizeObserver = new ResizeObserver(() => {
      const el = bodyRef.current;
      const checkScrollable = () => {
        if (el) {
          setIsScrollable(el.scrollHeight > el.clientHeight);
        }
      };
      checkScrollable();
    });

    const id = requestAnimationFrame(() => {
      if (bodyRef.current) {
        resizeObserver.observe(bodyRef.current);
      }
    });

    return () => {
      resizeObserver.disconnect();
      cancelAnimationFrame(id);
    };
  }, [open, children]);

  const closeButtonContext = useDesignSystemEventComponentCallbacks({
    componentType: DesignSystemEventProviderComponentTypes.Button,
    componentId: componentId ? `${componentId}.footer.cancel` : 'modal.close',
    analyticsEvents: [DesignSystemEventProviderAnalyticsEventTypes.OnClick],
    shouldStartInteraction,
  });
  const onCancelWrapper = (e: React.MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    closeButtonContext.onClick(e as any);
    onCancel?.(e);
  };

  const augmentedChildren = augmentWithDataComponentProps(children, eventContext.dataComponentProps);

  const dialogContent = (
    <Dialog.Content
      forceMount={destroyOnClose ? undefined : true}
      role="document"
      onInteractOutside={(e) => {
        e.preventDefault();
        if (dangerouslySetAntdProps?.maskClosable !== undefined && !Boolean(dangerouslySetAntdProps?.maskClosable)) {
          e.stopPropagation();
          return;
        }

        // Prevent infinite closing loop when opening a second modal/element that has a focusin event
        // This doesn't affect regular close logic
        if (e.detail.originalEvent.type === 'focusin') {
          return;
        }
        onCancel?.({} as any);
      }}
      onEscapeKeyDown={(e) => {
        e.preventDefault();
        if (dangerouslySetAntdProps?.keyboard !== undefined && !Boolean(dangerouslySetAntdProps?.keyboard)) {
          e.stopPropagation();
          return;
        }
        onCancel?.({} as any);
      }}
      css={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        inset: 0,
        top: '50%',
        padding: 0,
      }}
      className={`${classNamePrefix}-modal`}
      {...restProps}
    >
      <div
        className={classNames(className, `${classNamePrefix}-modal-content`)}
        ref={contentRef}
        css={[
          modalContainerStyles(theme),
          css({ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }),
          modalContentStyles(theme, verticalSizing === 'maxed_out'),
        ]}
        style={{
          width: dangerouslySetAntdProps?.width ?? (size ? SIZE_PRESETS[size] : undefined),
          maxWidth: '90vw',
          zIndex: zIndex ?? theme.options.zIndexBase,
          ...dangerouslySetAntdProps?.style,
        }}
        {...dangerouslySetAntdProps?.wrapProps}
      >
        <div css={modalHeaderStyles(theme)} className={`${classNamePrefix}-modal-header`}>
          <Dialog.Title asChild>
            <Typography.Title
              withoutMargins
              level={2}
              className={`${classNamePrefix}-modal-title`}
              css={modalTitleStyles(
                theme,
                truncateTitle,
                dangerouslySetAntdProps?.closable === undefined || dangerouslySetAntdProps?.closable,
              )}
              id={`modal-${uuid}`}
              // @ts-expect-error - used to prevent auto focusing the first focusable element when the modal is opened -- mimic antd behavior
              autoFocus={preventAutoFocus ? true : undefined}
              // used to prevent auto focusing the first focusable element when the modal is opened -- mimic antd behavior
              tabIndex={preventAutoFocus ? 0 : undefined}
            >
              {truncateTitle ? (
                <div
                  css={{
                    textOverflow: 'ellipsis',
                    overflow: 'hidden',
                    whiteSpace: 'nowrap',
                  }}
                  title={typeof title === 'string' ? title : undefined}
                >
                  {title}
                </div>
              ) : (
                title
              )}
            </Typography.Title>
          </Dialog.Title>
        </div>

        <div
          ref={bodyRef}
          css={modalBodyStyles(theme, footer !== null, isScrollable)}
          style={dangerouslySetAntdProps?.bodyStyle}
          className={`${classNamePrefix}-modal-body`}
        >
          {augmentedChildren}
        </div>

        {footer !== null && (
          <div
            css={modalFooterStyles(theme, classNamePrefix, footer !== null)}
            className={`${classNamePrefix}-modal-footer`}
          >
            {footer ?? (
              <DefaultFooter
                componentId={componentId}
                onOk={onOk}
                onCancel={onCancel}
                okText={okText}
                cancelText={cancelText}
                okButtonProps={okButtonProps}
                cancelButtonProps={cancelButtonProps}
                autoFocusButton={autoFocusButton}
                shouldStartInteraction={shouldStartInteraction}
                confirmLoading={confirmLoading}
              />
            )}
          </div>
        )}
        {dangerouslySetAntdProps?.closable === undefined || dangerouslySetAntdProps?.closable ? (
          <Dialog.Close asChild>
            <Button
              icon={dangerouslySetAntdProps?.closeIcon ?? <CloseIcon ref={elementRef} />}
              className={`${classNamePrefix}-modal-close`}
              name="Close"
              aria-label="Close"
              role="button"
              componentId={componentId ? `${componentId}.header.close` : 'modal.close'}
              onClick={onCancelWrapper}
              shouldStartInteraction={shouldStartInteraction}
              css={{ position: 'absolute', top: theme.spacing.md, right: theme.spacing.md }}
            />
          </Dialog.Close>
        ) : null}
      </div>
    </Dialog.Content>
  );

  // Don't change the structure, not using <Dialog.Overlay> as a content wrapper breaks select interactions
  // See problem: https://github.com/radix-ui/primitives/issues/1128
  // Solution: https://github.com/shadcn-ui/ui/issues/1175#issuecomment-2228543893

  // When modalRender is used, we apply it to the content before wrapping with overlay
  // This ensures the overlay still wraps the content (fixing select interactions)
  // while allowing custom rendering of the modal content
  const customModalRender = modalRender || dangerouslySetAntdProps?.modalRender;

  const renderedDialogContent = customModalRender ? customModalRender(dialogContent) : dialogContent;

  const dialogContentWithMask = (
    <div
      role="dialog"
      aria-labelledby={`modal-${uuid}`}
      aria-modal="true"
      ref={modalRootRef}
      aria-hidden={!open}
      css={wrapperStyles}
      className={classNames(wrapClassName)}
    >
      <RadixModalContext.Provider value={{ modalRootElement: modalRootRef.current?.firstChild as HTMLElement | null }}>
        {dangerouslySetAntdProps?.mask !== false ? (
          <Dialog.Overlay
            css={[overlayStyles(theme, zIndex ? zIndex : theme.options.zIndexBase, dangerouslySetAntdProps?.maskStyle)]}
          >
            {renderedDialogContent}
          </Dialog.Overlay>
        ) : (
          <>{renderedDialogContent}</>
        )}
      </RadixModalContext.Provider>
    </div>
  );

  // close immediately but open only after trigger button is captured
  const openState = !visible ? visible : open;

  return (
    <Dialog.Root
      modal
      open={openState}
      onOpenChange={(isOpen) => {
        if (!isOpen) onCancel?.({} as any); // only propagate close
      }}
    >
      <Dialog.Portal
        container={getContainer ? getContainer() : undefined}
        forceMount={destroyOnClose ? undefined : true}
      >
        {openState ? dialogContentWithMask : null}
      </Dialog.Portal>
    </Dialog.Root>
  );
}

export function DangerModal(props: Omit<ModalProps, 'footer'>): JSX.Element {
  const { theme } = useDesignSystemTheme();
  const { title, onCancel, onOk, cancelText, okText, okButtonProps, cancelButtonProps, confirmLoading, ...restProps } =
    props;
  const iconSize = 18;
  const iconFontSize = 18;
  const titleComp = (
    <div css={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}>
      <DangerIcon
        css={{
          color: theme.colors.textValidationDanger,
          left: 2,
          height: iconSize,
          width: iconSize,
          fontSize: iconFontSize,
        }}
      />
      <div css={{ paddingLeft: 6 }}>{title}</div>
    </div>
  );

  return (
    <Modal
      shouldStartInteraction={props.shouldStartInteraction}
      title={titleComp}
      footer={[
        <Button
          componentId={props.componentId ? `${props.componentId}.danger.footer.cancel` : 'modal.danger.cancel'}
          key="cancel"
          onClick={onCancel}
          shouldStartInteraction={props.shouldStartInteraction}
          {...cancelButtonProps}
        >
          {cancelText || 'Cancel'}
        </Button>,
        <Button
          componentId={props.componentId ? `${props.componentId}.danger.footer.ok` : 'modal.danger.ok'}
          key="discard"
          type="primary"
          danger
          onClick={onOk}
          loading={confirmLoading}
          shouldStartInteraction={props.shouldStartInteraction}
          {...okButtonProps}
        >
          {okText || 'Delete'}
        </Button>,
      ]}
      onOk={onOk}
      onCancel={onCancel}
      {...restProps}
    />
  );
}
