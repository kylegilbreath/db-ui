import { describe, it, expect, jest } from '@jest/globals';
import { render, screen, waitFor } from '@testing-library/react';

import { LegacySelect, DesignSystemProvider } from '..';
import { selectEvent } from '../../test-utils/rtl';

function renderSingleSelect(value = 'pie', onChange?: jest.Mock) {
  return render(
    <DesignSystemProvider>
      <LegacySelect aria-label="Fruit" id="test-select" value={value} onChange={onChange} style={{ width: 240 }}>
        <LegacySelect.Option value="pie">Pie</LegacySelect.Option>
        <LegacySelect.Option value="bar">Bar</LegacySelect.Option>
        <LegacySelect.Option value="line">Line</LegacySelect.Option>
      </LegacySelect>
    </DesignSystemProvider>,
  );
}

function renderMultiSelect(value = ['pie', 'bar'], onChange?: jest.Mock) {
  return render(
    <DesignSystemProvider>
      <LegacySelect
        aria-label="Fruit"
        id="test-multi-select"
        mode="multiple"
        value={value}
        onChange={onChange}
        style={{ width: 240 }}
      >
        <LegacySelect.Option value="pie">Pie</LegacySelect.Option>
        <LegacySelect.Option value="bar">Bar</LegacySelect.Option>
        <LegacySelect.Option value="line">Line</LegacySelect.Option>
      </LegacySelect>
    </DesignSystemProvider>,
  );
}

describe('LegacySelect accessibility', () => {
  describe('aria-description', () => {
    it('sets aria-description on the combobox input with the selected value', async () => {
      renderSingleSelect();
      await waitFor(() => {
        const combobox = screen.getByRole('combobox', { name: 'Fruit' });
        expect(combobox).toHaveAttribute('aria-description', 'Pie');
      });
    });

    it('preserves accessible name (aria-label) so consumer queries still work', () => {
      renderSingleSelect();
      const combobox = screen.getByRole('combobox', { name: 'Fruit' });
      expect(combobox).toBeInTheDocument();
    });
  });

  describe('single select', () => {
    it('describes the initial selected value on mount', async () => {
      renderSingleSelect('pie');
      await waitFor(() => {
        const combobox = screen.getByRole('combobox', { name: 'Fruit' });
        expect(combobox).toHaveAttribute('aria-description', 'Pie');
      });
    });

    it('updates aria-description when an option is selected', async () => {
      const onChange = jest.fn();
      renderSingleSelect('pie', onChange);
      const combobox = screen.getByRole('combobox', { name: 'Fruit' });

      await selectEvent.singleSelect(combobox, 'Bar');
      expect(onChange).toHaveBeenCalledWith('bar', expect.anything());

      await waitFor(() => {
        expect(combobox).toHaveAttribute('aria-description', 'Bar');
      });
    });
  });

  describe('multi select', () => {
    it('describes the initial selected values on mount', async () => {
      renderMultiSelect(['pie', 'bar']);
      await waitFor(() => {
        const combobox = screen.getByRole('combobox', { name: 'Fruit' });
        expect(combobox).toHaveAttribute('aria-description', 'Pie, Bar');
      });
    });

    it('updates aria-description when options are added', async () => {
      const onChange = jest.fn();
      renderMultiSelect(['pie', 'bar'], onChange);
      const combobox = screen.getByRole('combobox', { name: 'Fruit' });

      await selectEvent.multiSelect(combobox, ['Line']);
      expect(onChange).toHaveBeenCalledWith(['pie', 'bar', 'line'], expect.anything());

      await waitFor(() => {
        expect(combobox).toHaveAttribute('aria-description', 'Pie, Bar, Line');
      });
    });

    it('lists all selected options for single multi-select item', async () => {
      renderMultiSelect(['pie']);
      await waitFor(() => {
        const combobox = screen.getByRole('combobox', { name: 'Fruit' });
        expect(combobox).toHaveAttribute('aria-description', 'Pie');
      });
    });
  });

  describe('controlled value changes', () => {
    it('updates aria-description when value prop changes externally via rerender', async () => {
      const { rerender } = render(
        <DesignSystemProvider>
          <LegacySelect aria-label="Fruit" id="test-controlled" value="pie" style={{ width: 240 }}>
            <LegacySelect.Option value="pie">Pie</LegacySelect.Option>
            <LegacySelect.Option value="bar">Bar</LegacySelect.Option>
          </LegacySelect>
        </DesignSystemProvider>,
      );

      await waitFor(() => {
        const combobox = screen.getByRole('combobox', { name: 'Fruit' });
        expect(combobox).toHaveAttribute('aria-description', 'Pie');
      });

      rerender(
        <DesignSystemProvider>
          <LegacySelect aria-label="Fruit" id="test-controlled" value="bar" style={{ width: 240 }}>
            <LegacySelect.Option value="pie">Pie</LegacySelect.Option>
            <LegacySelect.Option value="bar">Bar</LegacySelect.Option>
          </LegacySelect>
        </DesignSystemProvider>,
      );

      await waitFor(() => {
        const combobox = screen.getByRole('combobox', { name: 'Fruit' });
        expect(combobox).toHaveAttribute('aria-description', 'Bar');
      });
    });
  });

  describe('no selection', () => {
    it('does not set aria-description when no value is selected', () => {
      render(
        <DesignSystemProvider>
          <LegacySelect aria-label="Fruit" id="test-empty-select" style={{ width: 240 }}>
            <LegacySelect.Option value="pie">Pie</LegacySelect.Option>
          </LegacySelect>
        </DesignSystemProvider>,
      );
      const combobox = screen.getByRole('combobox', { name: 'Fruit' });
      expect(combobox).not.toHaveAttribute('aria-description');
    });
  });
});
