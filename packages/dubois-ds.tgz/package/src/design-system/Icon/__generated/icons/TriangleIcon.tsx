import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgTriangleIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="M8 3a.75.75 0 0 1 .65.375l4.33 7.5A.75.75 0 0 1 12.33 12H3.67a.75.75 0 0 1-.65-1.125l4.33-7.5.056-.083A.75.75 0 0 1 8 3"
      />
    </svg>
  );
}
const TriangleIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgTriangleIcon} />;
});
TriangleIcon.displayName = 'TriangleIcon';
export default TriangleIcon;
