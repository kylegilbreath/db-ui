import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgLightningCircleFillIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0m.763 3.927a.38.38 0 0 0-.428.13l-3.326 4.35a.384.384 0 0 0 .304.616h1.664v2.687a.383.383 0 0 0 .688.233l3.326-4.35a.384.384 0 0 0-.304-.616H9.023V4.29a.38.38 0 0 0-.26-.363"
      />
    </svg>
  );
}
const LightningCircleFillIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgLightningCircleFillIcon} />;
});
LightningCircleFillIcon.displayName = 'LightningCircleFillIcon';
export default LightningCircleFillIcon;
