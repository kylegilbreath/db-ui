import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgPlusCircleSmallIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path fill="currentColor" d="M8.5 7h2.25v1.5H8.5v2.25H7V8.5H4.75V7H7V4.75h1.5z" />
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M7.75 1a6.75 6.75 0 1 1 0 13.5 6.75 6.75 0 0 1 0-13.5m0 1.5a5.25 5.25 0 1 0 0 10.5 5.25 5.25 0 0 0 0-10.5"
        clipRule="evenodd"
      />
    </svg>
  );
}
const PlusCircleSmallIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgPlusCircleSmallIcon} />;
});
PlusCircleSmallIcon.displayName = 'PlusCircleSmallIcon';
export default PlusCircleSmallIcon;
