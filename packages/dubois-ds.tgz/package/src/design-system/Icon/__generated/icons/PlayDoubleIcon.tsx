import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgPlayDoubleIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="M2.371 3.853a.75.75 0 0 1 .745-.007l6.25 3.5a.75.75 0 0 1 0 1.308l-6.25 3.5A.75.75 0 0 1 2 11.5v-7l.007-.099a.75.75 0 0 1 .364-.548"
      />
      <path
        fill="currentColor"
        d="M14.636 7.357a.75.75 0 0 1 0 1.287l-5.833 3.5-.772-1.287L12.792 8 7.864 5.044l.772-1.287z"
      />
    </svg>
  );
}
const PlayDoubleIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgPlayDoubleIcon} />;
});
PlayDoubleIcon.displayName = 'PlayDoubleIcon';
export default PlayDoubleIcon;
