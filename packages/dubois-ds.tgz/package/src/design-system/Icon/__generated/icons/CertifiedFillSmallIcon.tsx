import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgCertifiedFillSmallIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="M8 3c.71 0 1.33.37 1.686.928a1.997 1.997 0 0 1 2.385 2.385 1.996 1.996 0 0 1 0 3.373 1.996 1.996 0 0 1-2.385 2.385 1.996 1.996 0 0 1-3.373 0 1.996 1.996 0 0 1-2.385-2.385 1.996 1.996 0 0 1 0-3.373 1.997 1.997 0 0 1 2.385-2.385A2 2 0 0 1 8 3m-.675 5.22-.87-.871-.955.954 1.825 1.825L10.5 6.954 9.546 6z"
      />
    </svg>
  );
}
const CertifiedFillSmallIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgCertifiedFillSmallIcon} />;
});
CertifiedFillSmallIcon.displayName = 'CertifiedFillSmallIcon';
export default CertifiedFillSmallIcon;
