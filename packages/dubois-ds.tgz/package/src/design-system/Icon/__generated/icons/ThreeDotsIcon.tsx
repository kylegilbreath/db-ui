import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgThreeDotsIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 18 15" {...props}>
      <path
        fill="currentColor"
        d="M9 7.375A3.437 3.437 0 1 1 9 .5a3.437 3.437 0 0 1 0 6.875M13.688 8a3.438 3.438 0 1 0 0 6.875 3.438 3.438 0 0 0 0-6.875M4.313 8a3.437 3.437 0 1 0 0 6.875 3.437 3.437 0 0 0 0-6.875"
      />
    </svg>
  );
}
const ThreeDotsIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgThreeDotsIcon} />;
});
ThreeDotsIcon.displayName = 'ThreeDotsIcon';
export default ThreeDotsIcon;
