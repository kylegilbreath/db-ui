import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgTextJustifyIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="M15 15H1v-1.5h14zM15 11.75H1v-1.5h14zM15 8.75H1v-1.5h14zM15 5.75H1v-1.5h14zM15 2.5H1V1h14z"
      />
    </svg>
  );
}
const TextJustifyIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgTextJustifyIcon} />;
});
TextJustifyIcon.displayName = 'TextJustifyIcon';
export default TextJustifyIcon;
