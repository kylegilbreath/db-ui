import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgSortLetterVerticalAscendingIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <g fill="currentColor" clipPath="url(#SortLetterVerticalAscendingIcon_svg__a)">
        <path
          fillRule="evenodd"
          d="M4.307 0a.75.75 0 0 1 .697.473L7.596 7H5.982l-.238-.6H2.855l-.24.6H1L3.61.472A.75.75 0 0 1 4.307 0m-.852 4.9h1.693l-.844-2.124z"
          clipRule="evenodd"
        />
        <path d="M4.777 9.5H1.5V8h4.75a.75.75 0 0 1 .607 1.191L3.723 13.5H7V15H2.25a.75.75 0 0 1-.607-1.191zM12 .94l4.03 4.03-1.06 1.06-2.22-2.22V10h-1.5V3.81L9.03 6.03 7.97 4.97z" />
      </g>
      <defs>
        <clipPath>
          <path fill="#fff" d="M0 0h16v16H0z" />
        </clipPath>
      </defs>
    </svg>
  );
}
const SortLetterVerticalAscendingIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgSortLetterVerticalAscendingIcon} />;
});
SortLetterVerticalAscendingIcon.displayName = 'SortLetterVerticalAscendingIcon';
export default SortLetterVerticalAscendingIcon;
