import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgBackupIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 17 16" {...props}>
      <path
        fill="currentColor"
        d="M15.812 3.892v7.74a2.5 2.5 0 0 1-2.5 2.5h-9.1l-.255-.012a2.5 2.5 0 0 1-2.244-2.487V3.892l2-2.636h10.099zm-12.6 7.74a1 1 0 0 0 1 1h9.1a1 1 0 0 0 1-1V4.969h-11.1zm6.3-2.277 1.19-1.19 1.06 1.06-3 3.002L5.76 9.226l1.06-1.061 1.19 1.19v-3.86h1.5zM3.917 3.468h9.69l-.54-.712H4.458z"
      />
    </svg>
  );
}
const BackupIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgBackupIcon} />;
});
BackupIcon.displayName = 'BackupIcon';
export default BackupIcon;
