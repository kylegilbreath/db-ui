import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgChevronDoubleRightOffIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="m2.5 1.5 12 12-1 1-3.47-3.47-.97.97L8 10.94l.97-.97-.94-.94L5.06 12 4 10.94l2.97-2.97L1.5 2.5zM13.09 7.97l-1 1-4.03-4.03 1-1z"
      />
    </svg>
  );
}
const ChevronDoubleRightOffIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgChevronDoubleRightOffIcon} />;
});
ChevronDoubleRightOffIcon.displayName = 'ChevronDoubleRightOffIcon';
export default ChevronDoubleRightOffIcon;
