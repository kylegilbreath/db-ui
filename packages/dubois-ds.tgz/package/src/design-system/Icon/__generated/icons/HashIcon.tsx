import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgHashIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M11.67 5H15v1.5h-3.536l-.414 3H15V11h-4.156l-.552 4H8.777l.552-4H5.844l-.552 4H3.777l.552-4H1V9.5h3.535l.414-3H1V5h4.156l.552-4h1.515L6.67 5h3.485l.552-4h1.515zM6.05 9.5h3.485l.414-3H6.464z"
        clipRule="evenodd"
      />
    </svg>
  );
}
const HashIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgHashIcon} />;
});
HashIcon.displayName = 'HashIcon';
export default HashIcon;
