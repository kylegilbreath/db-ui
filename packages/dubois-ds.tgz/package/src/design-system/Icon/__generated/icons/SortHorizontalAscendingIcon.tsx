import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgSortHorizontalAscendingIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M1.47 5.03.94 4.5l.53-.53 3.5-3.5 1.06 1.06-2.22 2.22H10v1.5H3.81l2.22 2.22-1.06 1.06zM4.5 15v-4H6v4zm8 0V5H14v10zm-4-7v7H10V8z"
        clipRule="evenodd"
      />
    </svg>
  );
}
const SortHorizontalAscendingIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgSortHorizontalAscendingIcon} />;
});
SortHorizontalAscendingIcon.displayName = 'SortHorizontalAscendingIcon';
export default SortHorizontalAscendingIcon;
