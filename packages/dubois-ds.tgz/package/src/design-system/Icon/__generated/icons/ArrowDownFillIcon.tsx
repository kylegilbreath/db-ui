import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgArrowDownFillIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="M8 15.75a.75.75 0 0 1-.53-.22L1.22 9.28A.75.75 0 0 1 1.75 8H5.5V.75A.75.75 0 0 1 6.25 0h3.5a.75.75 0 0 1 .75.75V8h3.75a.751.751 0 0 1 .53 1.28l-6.25 6.25-.114.094A.75.75 0 0 1 8 15.75"
      />
    </svg>
  );
}
const ArrowDownFillIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgArrowDownFillIcon} />;
});
ArrowDownFillIcon.displayName = 'ArrowDownFillIcon';
export default ArrowDownFillIcon;
