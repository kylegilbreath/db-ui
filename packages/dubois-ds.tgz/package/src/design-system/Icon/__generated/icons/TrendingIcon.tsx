import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgTrendingIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="M6.332.14a.99.99 0 0 1 .98-.018c4.417 2.052 6.918 6.313 6.764 9.876-.066 1.497-.602 2.883-1.64 3.895-1.04 1.012-2.531 1.604-4.42 1.607a5.745 5.745 0 0 1-6.097-5.504v-.008a4.85 4.85 0 0 1 2.495-4.366.554.554 0 0 1 .776.261c.27.613.648 1.17 1.115 1.646.547-.714.8-1.637.792-2.652-.009-1.208-.388-2.502-1.024-3.605A.84.84 0 0 1 6.333.14"
      />
    </svg>
  );
}
const TrendingIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgTrendingIcon} />;
});
TrendingIcon.displayName = 'TrendingIcon';
export default TrendingIcon;
