import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgRichTextIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 18 18" {...props}>
      <path
        fill="currentColor"
        d="M16 16H2v-1.5h14zM16 12.75H2v-1.5h14zM9 3.5H6.25v6.25h-1.5V3.5H2V2h7zM16 9.75h-5.5v-1.5H16zM16 6.75h-5.5v-1.5H16zM16 3.5h-5.5V2H16z"
      />
    </svg>
  );
}
const RichTextIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgRichTextIcon} />;
});
RichTextIcon.displayName = 'RichTextIcon';
export default RichTextIcon;
