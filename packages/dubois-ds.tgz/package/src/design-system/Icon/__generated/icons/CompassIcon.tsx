import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgCompassIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M10.842 4.263a.75.75 0 0 1 .863 1l-1.664 4.346a.75.75 0 0 1-.432.432l-4.346 1.664a.75.75 0 0 1-.968-.968l1.664-4.346a.75.75 0 0 1 .432-.432l4.346-1.664zM6.296 9.704l2.465-.943-1.522-1.522z"
        clipRule="evenodd"
      />
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0m0 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13"
        clipRule="evenodd"
      />
    </svg>
  );
}
const CompassIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgCompassIcon} />;
});
CompassIcon.displayName = 'CompassIcon';
export default CompassIcon;
