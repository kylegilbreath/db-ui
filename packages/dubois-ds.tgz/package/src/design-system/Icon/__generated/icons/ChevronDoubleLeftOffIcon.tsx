import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgChevronDoubleLeftOffIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        d="m2.5 1.5 12 12-1 1-7.47-7.47-.94.94 2.97 2.97L7 12 2.97 7.97l2-2L1.5 2.5zM12.06 5l-1.97 1.97-1.06-1.06L11 3.94z"
      />
    </svg>
  );
}
const ChevronDoubleLeftOffIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgChevronDoubleLeftOffIcon} />;
});
ChevronDoubleLeftOffIcon.displayName = 'ChevronDoubleLeftOffIcon';
export default ChevronDoubleLeftOffIcon;
