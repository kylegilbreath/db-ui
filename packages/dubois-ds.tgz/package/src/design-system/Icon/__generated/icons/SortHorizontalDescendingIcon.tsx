import type { Ref } from 'react';
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from 'react';
import { forwardRef } from 'react';

import type { IconProps } from '../../Icon';
import { Icon } from '../../Icon';

function SvgSortHorizontalDescendingIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M3.5 15V5H2v10zm8 0v-4H10v4zm-4-7v7H6V8zm7.03-2.97.53-.53-.53-.53-3.5-3.5-1.06 1.06 2.22 2.22H6v1.5h6.19L9.97 7.47l1.06 1.06z"
        clipRule="evenodd"
      />
    </svg>
  );
}
const SortHorizontalDescendingIcon = forwardRef((props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
  return <Icon ref={forwardedRef} {...props} component={SvgSortHorizontalDescendingIcon} />;
});
SortHorizontalDescendingIcon.displayName = 'SortHorizontalDescendingIcon';
export default SortHorizontalDescendingIcon;
